// node --print_unopt_code --print_opt_code --always_opt example.js

function add(a, b) {
  return a + b;
}

add(1, 1);
